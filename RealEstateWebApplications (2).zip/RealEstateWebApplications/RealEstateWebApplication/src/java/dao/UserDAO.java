/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author ragno
 */

import java.util.List;
import model.User;

public interface UserDAO {
    void addUser(User user);
    User getUser(String username, String password);
    List<User> getAllUsers();

    public User authenticateUser(String username, String password);
}
