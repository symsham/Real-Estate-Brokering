// src/dao/PropertyDAOImpl.java
package dao;

import model.Property;
import util.Database_Util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PropertyDAOImpl implements PropertyDAO {

    @Override
    public void addProperty(Property property) throws SQLException {
        String sql = "INSERT INTO properties (name, price, seller_id) VALUES (?, ?, ?)";
        try (Connection conn = Database_Util.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, property.getName());
            ps.setDouble(2, property.getPrice());
            ps.setInt(3, property.getSellerId());
            ps.executeUpdate();
        }
    }

    @Override
    public void removeProperty(int propertyId) throws SQLException {
        String sql = "DELETE FROM properties WHERE id=?";
        try (Connection conn = Database_Util.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, propertyId);
            ps.executeUpdate();
        }
    }

    @Override
    public List<Property> getPropertiesBySeller(int sellerId) throws SQLException {
        List<Property> properties = new ArrayList<>();
        String sql = "SELECT * FROM properties WHERE seller_id=?";
        try (Connection conn = Database_Util.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sellerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Property property = new Property(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getInt("seller_id")
                );
                properties.add(property);
            }
        }
        return properties;
    }

    @Override
    public List<Property> getAllProperties() throws SQLException {
        List<Property> properties = new ArrayList<>();
        String sql = "SELECT * FROM properties";
        try (Connection conn = Database_Util.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Property property = new Property(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getInt("seller_id")
                );
                properties.add(property);
            }
        }
        return properties;
    }
}
