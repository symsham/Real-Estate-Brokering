// src/dao/PropertyDAO.java
package dao;

import model.Property;
import java.sql.SQLException;
import java.util.List;

public interface PropertyDAO {
    void addProperty(Property property) throws SQLException;
    void removeProperty(int propertyId) throws SQLException;
    List<Property> getPropertiesBySeller(int sellerId) throws SQLException;
    List<Property> getAllProperties() throws SQLException;
}
