/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author ragno
 */

import model.Buyer;
import java.util.List;

public interface BuyerDAO {
    void addBuyer(Buyer buyer);
    List<Buyer> getBuyersByProperty(int propertyId);
}
