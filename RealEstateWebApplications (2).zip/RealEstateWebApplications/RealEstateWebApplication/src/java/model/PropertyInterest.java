/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


public class PropertyInterest {

    private int propertyId;
    private String propertyName;
    private double propertyPrice;
    private String buyerName;
    private String buyerEmail;

    // Constructors
    public PropertyInterest() {
    }

    public PropertyInterest(int propertyId, String propertyName, double propertyPrice, String buyerName, String buyerEmail) {
        this.propertyId = propertyId;
        this.propertyName = propertyName;
        this.propertyPrice = propertyPrice;
        this.buyerName = buyerName;
        this.buyerEmail = buyerEmail;
    }

    // Getters and Setters
    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public double getPropertyPrice() {
        return propertyPrice;
    }

    public void setPropertyPrice(double propertyPrice) {
        this.propertyPrice = propertyPrice;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getBuyerEmail() {
        return buyerEmail;
    }

    public void setBuyerEmail(String buyerEmail) {
        this.buyerEmail = buyerEmail;
    }
}
