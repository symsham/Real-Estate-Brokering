package DatabaseConnectivity;

import dao.UserDAO;
import dao.UserDAOImpl;
import model.User;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/auth")
public class AuthServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    // Invalidate any existing session
    HttpSession existingSession = request.getSession(false);
    if (existingSession != null) {
        existingSession.invalidate();
    }

    String username = request.getParameter("username");
    String password = request.getParameter("password");

    // Check if the user exists in the database
    User user = userDAO.getUser(username, password);

    if (user != null) {
        HttpSession session = request.getSession(true);
        session.setAttribute("username", username);
        session.setAttribute("role", user.getRole());

        // Redirect based on user role
        switch (user.getRole()) {
            case "buyer":
                response.sendRedirect("buyer-dashboard.jsp");
                break;
            case "broker":
                response.sendRedirect("broker-dashboard.jsp");
                break;
            case "seller":
                response.sendRedirect("seller-dashboard.jsp");
                break;
            default:
                response.sendRedirect("index.jsp");
                break;
        }
    } else {
        response.sendRedirect("login.jsp?error=Invalid login");
    }
}
}
