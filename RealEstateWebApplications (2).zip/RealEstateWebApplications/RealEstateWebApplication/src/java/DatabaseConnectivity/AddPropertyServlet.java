package DatabaseConnectivity;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import util.Database_Util;

@WebServlet("/addProperty")
public class AddPropertyServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        int sellerId = Integer.parseInt(request.getParameter("sellerId"));

        try (Connection conn = Database_Util.getConnection()) {
            String sql = "INSERT INTO properties (name, price, seller_id) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setDouble(2, price);
            ps.setInt(3, sellerId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error occurred while adding the property.");
        }

        response.sendRedirect("broker");
    }
}
