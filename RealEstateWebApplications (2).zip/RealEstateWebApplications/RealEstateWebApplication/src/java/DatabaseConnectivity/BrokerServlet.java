package DatabaseConnectivity;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.PropertyInterest;
import util.Database_Util;

@WebServlet("/broker")
public class BrokerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<PropertyInterest> propertyInterests = new ArrayList<>();

        try (Connection conn = Database_Util.getConnection()) {
            String sql = "SELECT p.name, p.price, i.buyer_name, i.buyer_email " +
                         "FROM properties p " +
                         "LEFT JOIN InterestedProperties i ON p.id = i.property_id";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                PropertyInterest interest = new PropertyInterest();
                interest.setPropertyName(rs.getString("name"));
                interest.setPropertyPrice(rs.getDouble("price"));
                interest.setBuyerName(rs.getString("buyer_name"));
                interest.setBuyerEmail(rs.getString("buyer_email"));
                propertyInterests.add(interest);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error occurred.");
        }

        request.setAttribute("propertyInterests", propertyInterests);
        request.getRequestDispatcher("broker-dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("remove".equals(action)) {
            String propertyId = request.getParameter("propertyId");
            try (Connection conn = Database_Util.getConnection()) {
                String sql = "DELETE FROM properties WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(propertyId));
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Database error occurred while removing the property.");
            }
        }

        response.sendRedirect("broker");
    }
}
