package DatabaseConnectivity;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import static java.lang.System.out;
import java.util.ArrayList;
import java.util.List;
import model.Property;
import util.Database_Util;

@WebServlet("/seller")
public class SellerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Ensure seller ID is in the session
        Integer sellerId = (Integer) request.getSession().getAttribute("seller_id");
       
        if (sellerId == null) {
            response.sendRedirect("login.jsp?error=Please log in first.");
            return;
        }

        // Fetch properties for the seller's dashboard
        try (Connection conn = Database_Util.getConnection()) {
            String sql = "SELECT * FROM properties WHERE seller_id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, sellerId);
            ResultSet rs = ps.executeQuery();
            
            // Use a List to hold properties to pass to the JSP
            List<Property> properties = new ArrayList<>();
            while (rs.next()) {
                Property property = new Property();
                property.setId(rs.getInt("id"));
                property.setName(rs.getString("name"));
                property.setPrice(rs.getDouble("price"));
                property.setSellerId(rs.getInt("seller_id"));
                properties.add(property);
            }
            request.setAttribute("properties", properties);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exceptions appropriately
            request.setAttribute("error", "Database error occurred.");
        }
        request.getRequestDispatcher("seller-dashboard.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try (Connection conn = Database_Util.getConnection()) {
            Integer sellerId = (Integer) request.getSession().getAttribute("seller_id");
            if (sellerId == null) {
                response.sendRedirect("login.jsp?error=Please log in first.");
                return;
            }

            if ("add".equals(action)) {
                String sql = "INSERT INTO properties (name, price, seller_id) VALUES (?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, request.getParameter("name"));
                    ps.setDouble(2, Double.parseDouble(request.getParameter("price")));
                    ps.setInt(3, sellerId);
                    ps.executeUpdate();
                }
            } else if ("remove".equals(action)) {
                String sql = "DELETE FROM properties WHERE id=?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, Integer.parseInt(request.getParameter("propertyId")));
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exceptions appropriately
            request.setAttribute("error", "Database error occurred.");
            request.getRequestDispatcher("seller-dashboard.jsp").forward(request, response);
            return;
        }
         finally {
    out.println("seller_id");
}
        response.sendRedirect("seller-dashboard.jsp");
       
    }
    
}
