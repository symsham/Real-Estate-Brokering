/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package DatabaseConnectivity;

/**
 *
 * @author ragno
 */


import dao.PropertyDAOImpl;
import model.Property;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/property")
public class PropertyServlet extends HttpServlet {

    private PropertyDAOImpl propertyDAO;

    @Override
    public void init() throws ServletException {
        propertyDAO = new PropertyDAOImpl();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer sellerId = (Integer) session.getAttribute("seller_id");

        if (sellerId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");

        try {
            if ("add".equals(action)) {
                String name = request.getParameter("name");
                double price = Double.parseDouble(request.getParameter("price"));
                Property property = new Property(0, name, price, sellerId);

                propertyDAO.addProperty(property);

            } else if ("remove".equals(action)) {
                int propertyId = Integer.parseInt(request.getParameter("propertyId"));
                propertyDAO.removeProperty(propertyId);
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Invalid price or property ID.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error occurred.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }
    }
}

    
