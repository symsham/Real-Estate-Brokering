package DatabaseConnectivity;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.Database_Util;

@WebServlet("/buyer")
public class BuyerServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("submitInterest".equals(action)) {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String propertyId = request.getParameter("propertyId");

            try (Connection conn = Database_Util.getConnection()) {
                String insertInterestSQL = "INSERT INTO InterestedProperties (property_id, buyer_name, buyer_email) VALUES (?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(insertInterestSQL)) {
                    ps.setString(1, propertyId);
                    ps.setString(2, name);
                    ps.setString(3, email);
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Database error occurred while submitting interest.");
            }

            // Set a success message for the buyer's dashboard
            request.setAttribute("success", "Request sent successfully.");

            // Forward back to the buyer dashboard
            request.getRequestDispatcher("buyer-dashboard.jsp").forward(request, response);
        }
    }
}
