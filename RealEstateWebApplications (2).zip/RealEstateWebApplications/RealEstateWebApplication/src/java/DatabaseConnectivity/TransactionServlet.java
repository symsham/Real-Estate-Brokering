

    package DatabaseConnectivity;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Transaction;
import util.Database_Util;

@WebServlet("/processTransaction")
public class TransactionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String buyerName = request.getParameter("buyerName");
        String buyerEmail = request.getParameter("buyerEmail");
        double amount = Double.parseDouble(request.getParameter("amount"));
        int propertyId = Integer.parseInt(request.getParameter("propertyId"));

        Transaction transaction = new Transaction();
        transaction.setBuyerName(buyerName);
        transaction.setBuyerEmail(buyerEmail);
        transaction.setAmount(amount);
        transaction.setPropertyId(propertyId);

        try (Connection conn = Database_Util.getConnection()) {
            String sql = "INSERT INTO transactions (property_id, buyer_name, buyer_email, amount) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, transaction.getPropertyId());
            ps.setString(2, transaction.getBuyerName());
            ps.setString(3, transaction.getBuyerEmail());
            ps.setDouble(4, transaction.getAmount());
            ps.executeUpdate();

            request.setAttribute("message", "Transaction successful!");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Transaction failed. Please try again.");
        }

        request.getRequestDispatcher("transaction.jsp").forward(request, response);
    }
}
